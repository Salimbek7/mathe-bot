import os

TOKEN = os.getenv('BOT_TOKEN')